
// const fullname = document.getElementById('fullname')
// const email = document.getElementById('email')
// const username = document.getElementById('username')
// const password = document.getElementById('password')
// const address = document.getElementById('address')
// const confirmpass = document.getElementById('confirmpass')
// const form = document.getElementById('form')
// const errorElement = document.getElementById('error')

// var pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
// function {
//     messages.push('ppppp')
// }
// function lettersOnly(input) {
//     var regex = /[^a-z]/gi;
//     input.value = input.value.replace(regex, "");
// }

// function noSpecialcharacters(input) {
//     var regex = /[^a-zA-Z0-9]/gi;
//     input.value = input.value.replace(regex, "");
// }



// form.addEventListener('submit', (e) => {
    
//     let messages = []



//     if(fullname.value.length <= 1) {
//         messages.push('Your last name cannot only conatin a single letter.')
//     }

//     if(password.value.length < 8) {
//         messages.push('Password must be 8 characters or longer.')
//     }

//     if((confirmpass.value.length != password.value.length) || (confirmpass.value != password.value)) {
//         messages.push('Please re-enter your chosen password correctly.')
//     }

//     if(messages.length > 0) {
//         e.preventDefault()
//         errorElement.innerText = messages.join(' ')
//     }

//     validateInputs();

// })

//sign in validation

const email = document.getElementById('email')
const username = document.getElementById('username')
const phone = document.getElementById('phone')
const password = document.getElementById('password')
const confirmpass = document.getElementById('confirmpass')
const form = document.getElementById('form')
const errorElement = document.getElementById('errorMsg')

// var pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

function NoSpecialChar(input) {
    var regex = /[^a-zA-Z0-9]/gi;
    input.value = input.value.replace(regex, "");
}

function OnlyNum(input) {
    var regex = /[^0-9]/gi;
    input.value = input.value.replace(regex, "");
}

form.addEventListener('submit', (e) => {

    let messages = []
    if (email.value === ''  email.value == null) {
        messages.push('Please enter your email.')
    }

    if (username.value === ''  username.value == null) {
        messages.push('Please enter your preferred username.\n')
    }

    if (password.value == ''  password.value == null) {
        messages.push('Please enter a password.')
    }

    if (password.value.length < 8) {
        messages.push('Password must be 8 characters or longer.\n')
    }

    if (phone.value.length < 7) {
        messages.push('Phone number must be 7 digits or longer.\n')
    }

    if (phone.value.length > 15) {
        messages.push('Phone number cannot be more than 15 digits.\n')
    }

    if ((confirmpass.value.length != password.value.length)  (confirmpass.value != password.value)) {
        messages.push('Please re-enter your chosen password correctly.')

    }
    if (messages.length > 0) {
        e.preventDefault()
        errorElement.innerText = messages.join(' ')
    }

})